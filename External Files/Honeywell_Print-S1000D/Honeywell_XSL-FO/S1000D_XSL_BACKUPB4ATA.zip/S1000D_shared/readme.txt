This directory contains XSL that is shared between the EM and EIPC FO applications.
At some point we may want to include some of the CMM XSL, but for now that is stand-alone.
